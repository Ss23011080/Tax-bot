
# ربات تلگرام مشاور مالیاتی - سمیرا سلیمی

## مراحل اجرا در Render.com

1. به سایت [https://render.com](https://render.com) بروید و وارد حساب شوید.
2. روی "New" کلیک کنید و "Web Service" را انتخاب کنید.
3. گزینه "Deploy from Git" را نادیده بگیرید و دکمه "Manual Deploy" را انتخاب کنید.
4. فایل `bot.py` و `requirements.txt` را آپلود کنید.
5. در قسمت "Start Command"، این دستور را وارد کنید:
    ```
    python bot.py
    ```
6. نوع محیط را روی Python قرار دهید.
7. روی "Create Web Service" کلیک کنید.

ربات شما پس از چند ثانیه فعال خواهد شد.

**ربات:** @Ss2301208376bot
